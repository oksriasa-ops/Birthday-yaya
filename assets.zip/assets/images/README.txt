Optional folder for any extra images you want to add.
